package br.poo.apinewbank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewBankApplication {

    public static void main(String[] args) {
        SpringApplication.run(NewBankApplication.class, args);
    }

}
