package br.poo.apinewbank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewBankApplicationTests {

    @Test
    void contextLoads() {
    }

}
